package Collections;
import java.util.*;
public class arr_list {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ArrayList<String> product = new ArrayList();
		product.add("Clothes");
		product.add("Animal Toys");
		product.add("Books");
		
		for (String i:product) {
		System.out.println(i);
		}
		
		Collections.sort(product);
		System.out.println("After Sorting");

		for (String i:product) {
		System.out.println(i);
		}
		
	}

}
