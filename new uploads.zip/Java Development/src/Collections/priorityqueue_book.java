package Collections;
import java.util.*;

class book1 {
	String name,title,author;
	int sales;
	
	
	book1(String name, String title, String author, int sales)
	{
		this.name=name;
		this.title=title;
		this.author=author;
		this.sales=sales;
	}
}
public class priorityqueue_book {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<String> q= new PriorityQueue();
		
		q.add("Winner");
		q.add("money");
		q.add("power");
		q.add("Success");
		

		System.out.println("Head :" + q.element());
		System.out.println("Head :" + q.peek());
		
		
		System.out.println("Queue Iteration");
		
		Iterator i = q.iterator();
		
		while (i.hasNext()) 
		{
			System.out.println(i.next());
		}
		
		q.poll();
		q.remove();
		
		Iterator j = q.iterator();
		
		while (j.hasNext()) 
		{
			System.out.println(j.next());
		}
		
		
		q.poll();
		q.remove();
		
	
		
		book1 b = new book1("Sheikh", "Sheikh", "Sheikh", 4500);
		
		System.out.println(b.author+b.name+b.sales+b.title);
		
	}

}
