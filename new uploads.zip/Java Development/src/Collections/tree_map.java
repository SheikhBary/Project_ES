package Collections;
import java.util.*;
import java.util.Map.Entry;;
public class tree_map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		TreeMap<Integer, String> tm = new TreeMap<Integer, String> ();
		
		tm.put(100, "vijay");
		tm.put(101, "arul");
		
		tm.put(102, "varun");
		tm.put(103, "ajay");
		tm.put(104, "chauhan");
		tm.put(105, "dinanath");

		
		for (Map.Entry m :tm.entrySet())
		{
			System.out.println(m.getKey()+ "  " +m.getValue());
		}
		
		
		
		
		
		tm.remove(101);
		System.out.println("After removing");
		for (Map.Entry m :tm.entrySet())
		{
			System.out.println(m.getKey()+ "  " +m.getValue());
		}
		System.out.println("Descending Order :"+tm.descendingMap());
		System.out.println("Head Map :"+tm.headMap(102, true));
		System.out.println("Tail Map :"+tm.tailMap(103, true));
		System.out.println("Sub Map :"+tm.subMap(103, true,104, false));
		
	}

}
