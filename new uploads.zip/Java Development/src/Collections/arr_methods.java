package Collections;
import java.util.*;
public class arr_methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		ArrayList<String> a1 = new ArrayList<String>();
		
		System.out.println("Initial Array List");
		
		a1.add("Ravi");
		a1.add("Peter");
		a1.add("Ajay");
		
		System.out.println("After invoking add()"+a1);
		
		
		ArrayList<String> a2 = new ArrayList<String>();
		a2.add("Samantha");
		a2.add("Silver");
		a1.addAll(a2);
		
		System.out.println("After invoking addAll()"+a1);
		
		ArrayList<String> a3 = new ArrayList<String>();
		a3.add("Sheikh");
		a3.add("Umar");
		a1.addAll(0,a3);
		
		System.out.println("After invoking addAll()"+a1);
		
		
	}

}
