package Collections;
import java.util.*;

class Student {
	
	int rollno;
	String name;
	int age;
	
	Student(int rollno, String name, int age){
		this.rollno=rollno;
		this.name=name;
		this.age=age;
	}

}
public class arr_list_user {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s1 = new Student(101, "Sheikh",22);
		Student s2 = new Student(202, "Abdul",23);
		Student s3 = new Student(103, "Bary",24);
		
		ArrayList <Student> a1 = new ArrayList();
		
		a1.add(s1);
		a1.add(s2);
		a1.add(s3);
		
		Iterator i = a1.iterator();
		
		while (i.hasNext()) {
			
			Student st= (Student) i.next();
			
			System.out.println(st.rollno + " : " + st.name+" : "+ st.age+" : ");
		}
		
		// HashSet Example 
		
		HashSet<String> set= new HashSet<String>();
		
		set.add("John");
		set.add("Joe");
		set.add("Jack");
		set.add("Jill");
		
		Iterator s12 = set.iterator();
		
		while (s12.hasNext()) {
			String str =(String) s12.next();
			System.out.println(str);
			
		
		
		}
		
		if (set.contains("Jack")) {
			set.remove("Jack");
			
		}

	}
	


}
