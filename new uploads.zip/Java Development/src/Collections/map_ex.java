package Collections;
import java.util.*;
public class map_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer,String> Stu = new HashMap<Integer, String>();
		
		Stu.put(10011, "Gaurav");
		Stu.put(10022, "Vimal");
		Stu.put(101, "Kumar");
		Stu.put(33, "Abhi");
		
		
		for ( Map.Entry m :Stu.entrySet())
		{
			
			System.out.println(m.getKey()+ "  " + m.getValue());
		}
		
		
	}

}
