package Collections;

import java.util.LinkedList;
import java.util.*;
public class linked_list2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
LinkedList ll =new LinkedList<String>();
        
        ll.add("Ravi");
        ll.add("Vijay");
        ll.add("Ajay");
        ll.add("Anuj");
        ll.add("Gaurav");
        ll.add("Harsh");
        ll.add("Virat");
        ll.add("Gaurav");
        ll.add("Harsh");
        ll.add("Amit");
        
        System.out.println("Initial Elements:"+ll);
        
        11.set(2,"Arul");
        System.out.println("Initial Elements:"+ll);
		
        Collections.sort(11);
        System.out.println("After Sorting:"+ll);
		

	}



}
