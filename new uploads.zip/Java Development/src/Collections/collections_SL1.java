package Collections;
import java.util.*;
public class collections_SL1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//LINKED LIST
		
		LinkedList <String> L = new LinkedList<String>();
		System.out.println("This is Linked List");
		L.add("Ajay");
		L.add("Vijay");
		L.add("Vijay");
		L.add("Varun");
		
		Iterator <String> str = L.iterator();
		while(str.hasNext()){  
			System.out.println(str.next());  
			}  
		
		// 2 ways to print either use iterator or Traversing Elements
		
		for(String str1:L) {
			System.out.println(str1);
		}
		//Array List
		System.out.println("This is Array List");
		
		
		ArrayList<String> a = new ArrayList<String>();
		
		a.add("Ajay");
		a.add("Vijay");
		a.add("Vijay");
		a.add("Varun");
		
		for (String str2:a)
		{
			
			System.out.println(str2);
		}
		// Vector list
System.out.println("This is Vector List");
		
		
		Vector<String> a3 = new Vector<String>();
		
		a3.add("Ajay");
		a3.add("Vijay");
		a3.add("Vijay");
		a3.add("Varun");
		
		for (String str3:a3)
		{
			
			System.out.println(str3);
		}
		
		
		// Stack list
		System.out.println("This is Stack List");
				
				
				Stack<String> a4 = new Stack<String>();
				
				a4.add("Ajay");
				a4.add("Vijay");
				a4.add("Vijay");
				a4.add("Varun");
				
				for (String str4:a4)
				{
					
					System.out.println(str4);
				}
				
				//SET
				
		// HashSet
		// Does not allow duplicate data
			System.out.println("This is Hash Set");
						
						
			HashSet<String> h = new HashSet<String>();
						
				h.add("Ajay");
				h.add("Vijay");
				h.add("Vijay");
				h.add("Varun");
						
				for (String str5:h)
				{
							
					System.out.println(str5);
				}
				
				// Linked Hash Set
				// Does not allow duplicate data
				System.out.println("This is Linked Hash Set");
							
							
				LinkedHashSet<String> l = new LinkedHashSet<String>();
							
					l.add("Ajay");
					l.add("Vijay");
					l.add("Vijay");
					l.add("Varun");
							
					for (String str6:l)
					{
								
						System.out.println(str6);
					}
					// Tree Set
					// Does not allow duplicate data
					System.out.println("This is Tree Set");
								
								
					TreeSet<String> t = new TreeSet<String>();
								
						t.add("Ajay");
						t.add("Vijay");
						t.add("Vijay");
						t.add("Varun");
								
						for (String str7:t)
						{
									
							System.out.println(str7);
						}
																	
		//QUEUE
						
						System.out.println("This is Array Deque");
						
						
						ArrayDeque<String> ad = new ArrayDeque<String>();
									
						ad.add("Ajay");
						ad.add("Vijay");
						ad.add("Vijay");
						ad.add("Varun");
									
							for (String str8:ad)
							{
										
								System.out.println(str8);
							}		
					System.out.println("This is Priority Queue");
							
							
				PriorityQueue<String> pq = new PriorityQueue<String>();
										
				pq.add("Ajay");
				pq.add("Vijay");
				pq.add("Vijay");
				pq.add("Varun");
									
				pq.remove();
				pq.poll();
				
						for (String str9:pq)
						{
									
							System.out.println(str9);
						}	
						
						

	}

}
