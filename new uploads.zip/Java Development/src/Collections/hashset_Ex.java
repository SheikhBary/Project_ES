package Collections;
import java.util.*;
public class hashset_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			HashSet set = new HashSet();
			
			set.add("Ravi");
			set.add("Ravi");
			set.add("Vijay");
			set.add("Ajay");
			set.add(null);
			
			Iterator i1 = set.iterator();
			while (i1.hasNext()) {
				System.out.println(i1.next());
			}
	}

}
