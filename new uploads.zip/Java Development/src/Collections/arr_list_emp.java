 package Collections;
import java.util.*;

class employee{
	
	int salary;
	String Name;
	int id;
	
	employee(int salary, String Name, int id){
		
		this.salary=salary;
		this.Name=Name;
		this.id=id;
	}
}
public class arr_list_emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		employee e1 = new employee(1500, "Sheikh",101);
		employee e2 = new employee(2500, "Abdul",202);
		employee e3 = new employee(3500, "Bary",425);
		
		ArrayList <employee> ep = new ArrayList();
		
		ep.add(e1);
		ep.add(e2);
		ep.add(e3);
		
		Iterator i = ep.iterator();
		while (i.hasNext())
			
		{
			
			
			employee p = (employee) i.next();
			
			System.out.println(p.id + p.Name + p.salary);
		}

	}

}
