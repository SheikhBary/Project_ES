package Collections;

import java.util.*;
import java.util.Iterator;
import java.util.LinkedList;

public class linked_ex {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
	LinkedList emp = new LinkedList();
		
		emp.add(1011);
		emp.add("Rani");
		emp.add("India");
		emp.add("India");
		
		System.out.println(emp);
		
		Iterator i = emp.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		

	}

		
}
}