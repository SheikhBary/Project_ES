package Collections;
import java.util.*;


public class arraydequeue_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
		ArrayDeque emp = new ArrayDeque();
		System.out.println("Before Removing");
		emp.add("Hello");
		emp.add("Rani");
		emp.add("India");
		emp.add("India");
		
		System.out.println(emp);
		
		Iterator i = emp.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
			

	}
		
		System.out.println("After Removing");
		 emp.pollLast(); 
		 
		 Iterator i1 = emp.iterator();
			while (i1.hasNext()) {
				System.out.println(i1.next());
			} 
			
			
			System.out.println("After Adding");
			 emp.addFirst("Blue");
			 emp.addLast("Blue");
			 
			 
					System.out.println(emp);
				

}
}