package Collections;
import java.util.*;

class Book {
	
	
	int id; 
	String name,author,publisher;
	int nos;
	
	public Book ( int id, String name, String author, String publisher, int nos) {
		this.id=id;
		this.name=name;
		this.author=author;
		this.publisher=publisher;
		this.nos=nos;
	}
}
public class linked_listbook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Book> list = new LinkedList<Book>();
		
		
		Book b1 = new Book(101,"C programming","Sheikh", "James sir",7);
		Book b2 = new Book(102,"Phyton programming","Abdul", "Kunal",7);
		Book b3 = new Book(104,"Java programming","Bary", "Peter",7);
		
		list.add(b1);
		list.add(b2);
		list.add(b3);
		
		for (Book b:list)
		{
			System.out.println(b.id+""+b.name+""+b.author+""+b.publisher+""+b.nos);
		}
		
		
	}

}
