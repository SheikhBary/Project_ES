package Collections;
import java.util.*;
public class hashset_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> hs = new HashSet<String>();
		
		
		hs.add("Raja");
		hs.add("Ram");
		hs.add("Kumar");
		hs.add("Venkat");
		hs.add("John");
		hs.add("Kiera");
		
		System.out.println(" An initial Set :" + hs);
		
		hs.remove("Raja");
		System.out.println("After Remove :" + hs);
		
		HashSet<String> hs2 = new HashSet<String>();
		hs2.add("Malini");
		hs2.add("Shalini");
		
		hs.addAll(hs2);
		System.out.println("After Adding :" + hs);
		
		hs.removeAll(hs2);
		System.out.println("After Removing All :" + hs);
		
		hs.clear();
		System.out.println("After Clearing :" + hs);
	}

}
