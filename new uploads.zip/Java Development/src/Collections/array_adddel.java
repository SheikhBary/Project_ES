package Collections;

import java.util.ArrayList;
import java.util.*;
public class array_adddel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
		ArrayList<String> a1 = new ArrayList<String>();
		
		System.out.println("Initial Array List");
		
		a1.add("Ravi");
		a1.add("Peter");
		a1.add("Ajay");
		
		System.out.println("After invoking add()"+a1);
		
		a1.remove(0);
		a1.remove(1);
		
		System.out.println("After invoking add()"+a1);
		
		ArrayList<String> a2 = new ArrayList<String>();
		a2.add("Samantha");
		a2.add("Sam");
		a2.add("Sheikh");
		a2.add("Eugene");
		
		a1.addAll(a2);
		
		System.out.println("After invoking addAll()"+a1);
		
		
		a1.remove(0);
		a1.remove(1);
		a1.removeAll(a2);
		
		System.out.println("After Removing"+a1);
		
		

	}

}
