package Collections;
import java.util.*;

class emp {
	
	int id,age,salary;
	String name;
	
	public emp(int id, int age, int salary,String name) {
		
		this.id=id;
		this.age=age;
		this.name=name;
		this.salary=salary;
		
	}
	
}
public class linkedlist_emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<emp> list = new LinkedList<emp>();
		
		emp e1 = new emp (101,22,2500,"Sheikh");
		emp e2 = new emp (202,24,5000,"Abdul");
		emp e3 = new emp (303,45,4500,"Bary");
		
		list.add(e1);
		list.add(e2);
		list.add(e3);
		
		
		for (emp e :list)
		{
			
			System.out.println(e.age+" "+e.id + " " + e.salary + " "+ e.name);
		}

	}

}
