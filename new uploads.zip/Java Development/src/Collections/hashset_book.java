package Collections;
import java.util.*;
public class hashset_book {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet <String> hs = new HashSet <String>();
		
		hs.add("Kindle");
		hs.add("Sucess");
		hs.add("Mind");
		hs.add("Capitalism");
		hs.add("Socialism");
		
		System.out.println("Inital Library :"+hs);
		
		HashSet <String> hs1 = new HashSet <String>();
		hs1.add("Money");
		hs1.add("Power");
		
		hs.addAll(hs1);
		System.out.println("After New Additions :"+hs);
		
		
		hs.removeAll(hs1);
		System.out.println("After Removing New Additions :"+hs);
		
		
		hs.clear();
		System.out.println("After Clearing" + hs);
		
		
	}

}
