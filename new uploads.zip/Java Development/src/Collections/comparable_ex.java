package Collections;
import java.util.*;


class Stu implements Comparable <Stu>
{
	int regNo, age;
	String name;
	
	Stu (int regNo, int age, String name)
	{
		this.regNo=regNo;
		this.age=age;
		this.name=name;
	}
	
	public int compareTo(Stu s) {
		{
			if (age ==s.age)
				
				return 0;
			else if (age>s.age)
				return 1;
			else 
					return -1;
		}

	}
}
public class comparable_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ArrayList<Stu> a1 = new ArrayList<Stu>();
		
		a1.add(new Stu(101, 25, "Anuj"));
		a1.add(new Stu(101, 25, "Varun"));
		a1.add(new Stu(101, 25, "Ajay"));
		
		
		Collections.sort(a1);
		
		for (Stu st:a1)
		{
			
			System.out.println(st.age+st.regNo+st.name);
		}
	}

}
