package Collections;
import java.util.*;
public class PriorityQueue_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<String> q= new PriorityQueue();
		
		q.add("Raja");
		q.add("Ram");
		q.add("Kumar");
		q.add("Venkat");
		q.add("John");
		q.add("Kiera");
		
		System.out.println("Head :" + q.element());
		System.out.println("Head :" + q.peek());
		
		
		System.out.println("Queue Iteration");
		
		Iterator i = q.iterator();
		
		while (i.hasNext()) 
		{
			System.out.println(i.next());
		}
		
		q.poll();
		q.remove();
		
		Iterator j = q.iterator();
		
		while (j.hasNext()) 
		{
			System.out.println(j.next());
		}
		
		q.poll();
		q.remove();
		
	}

}
