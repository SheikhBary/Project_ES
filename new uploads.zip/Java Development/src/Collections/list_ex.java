package Collections;

import java.util.*;

public class list_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ArrayList emp = new ArrayList();
		
		emp.add(1011);
		emp.add("Rani");
		emp.add("India");
		emp.add("India");
		
		System.out.println(emp);
		
		Iterator i = emp.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
	}
}
