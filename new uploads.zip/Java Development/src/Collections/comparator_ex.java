package Collections;


public class Human
{
    String name;
    int age;
    Human()
    {
        name="NoName";
        age=0;
    }
    Human(String name, int age)
    {
        this.name=name;
        this.age=age;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setName(String name) {
        this.name = name;    
    }
    public static Comparator<Human> ageComparator=new Comparator<Human>()
    {
        public int compare(Human h1, Human h2)
        {
            return h1.getAge()-h2.getAge();
        }
    };
    public static Comparator<Human> nameComparator=new Comparator<Human>()
    {
        public int compare(Human h1, Human h2)
        {
            return h1.getName().compareTo(h2.getName());
        }
    };
public class comparator_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 ArrayList<Human> humans = new ArrayList<>();
		    humans.add(new Human("Shraman", 21));
		    humans.add(new Human("Shubham", 23));
		    humans.add(new Human("Pranav", 20));
		    humans.add(new Human("Srijan", 19));
		    humans.add(new Human("Gourav", 24));
		    humans.add(new Human("Amit", 11));
		    humans.add(new Human("Raju", 41));
		    System.out.println("Before sorting");
		    humans.forEach((n)-> System.out.print(n.name+" "+n.age+" \n"));
		    System.out.println("\n After Sorting by age");
		    Collections.sort(humans, ageComparator );
		    humans.forEach((n)-> System.out.print(n.name+" "+n.age+" \n"));
		    System.out.println("\n After sorting by Name");
		    
		    Collections.sort(humans, nameComparator );
		    humans.forEach((n)-> System.out.print(n.name+" "+n.age+" \n"));
		}
		}
		Output:


		Before sorting
		Shraman 21
		Shubham 23
		Pranav 20
		Srijan 19
		Gourav 24
		Amit 11
		Raju 41After Sorting by age
		Amit 11
		Srijan 19
		Pranav 20
		Shraman 21
		Shubham 23
		Gourav 24
		Raju 41
		After sorting by Name
		Amit 11
		Gourav 24
		Pranav 20
		Raju 41
		Shraman 21
		Shubham 23
		Srijan 19

		As we can observe, the comparator method is an easier method of arranging the data items according to a particular logic. Point to note is that this example corresponds to the new way of using Java generics to implement individual comparators for.

		Basic Differences between Comparable and Comparator in Java

		The comparable interface can only be useful for sorting the elements in a class in a single way. However, the comparator interface is useful for sorting multiple types of data in a class.
		While using comparable Interfaces, the class itself has to implement the interface. However, we may choose to implement or not implement the Comparator interface in the base class. You can take advantage of anonymous classes in Java to leverage this issue.
		While using the Comparable interface, we do not need to make any changes to the code. This is because the sort functions of the collections class automatically use the compareTo method in the class. However, while we implement the Comparator interface, we need to use the comparator name along with the sort function.
		The java.lang houses the Comparable interface whereas the java. util package contains the Comparator interface. You have to be cautious while using interfaces because you would run into errors if you do not import the correct package.
		Rules for Using Comparator Interface
		There are certain rules that you should keep in mind before actually attempting to implement an interface. Some of them are:

		You can use the Comparator interface to sort the elements of the collection.
		If you keep your object type as undefined while implementing the Comparator Interface, then you need to make sure that you typecast all the variables inside it to the Object inside the method.
		You need to specify the generic of the user datatype while passing it to a comparator. If you do not then java converts it to an Object type by default. You would not be able to compare individual elements after that.
		Summary
		In this article, we came to know about the various uses of the comparator interface. We also came to know about the process of using Comparator Interfaces in programs to structure classes easily. We now know comparable interface and comparator interface, and how they are different from each other. This is a very popular question in interviews.

		You give me 15 seconds I promise you best tutorials
		Please share your happy experience on Google | Facebook



		Tags: Comparator Interface in JavaJava ComparatorJava Comparator exampleJava Comparator InterfaceWorking of Collections.Sort()

		LEAVE A REPLY
		Comment *

		Name *
		Email *
		This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply.





		Home About us Contact us Terms and Conditions Privacy Policy Disclaimer Write For Us Success Stories

		DataFlair � 2022. All Rights Reserved.



	}

}
