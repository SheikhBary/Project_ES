package Looping_stmts;
import java.util.Scanner;

public class while_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner (System.in);
		
		int i, nos;
		String emp_name,doj;
		int emp_id;
		float bas_sal,hra,da,tax,pr, tot_ear, tot_ded, gross;
		
		
		i=0;
		
		System.out.println("Enter the number of employee ");
		nos=s.nextInt();
		
		while (i<nos) {
			
			System.out.println("Enter Employee Name");
			emp_name=s.next();
			
			System.out.println("Enter Employee Id");
			emp_id=s.nextInt();
			
			System.out.println("Enter Employee Salary");
			bas_sal=s.nextFloat();
			
			
			
			if(bas_sal> 1000 && bas_sal< 2000) {
				
				hra=12*10/100;
				da=bas_sal*10/100;
				tax=bas_sal*12/100;
				pr=bas_sal*8/100;
			}
			
			else if(bas_sal> 2000 && bas_sal< 3000) {
				
				hra=15*10/100;
				da=bas_sal*15/100;
				tax=bas_sal*14/100;
				pr=bas_sal*10/100;
				
			}

			else if(bas_sal> 3000) {
				
				
				hra=17*10/100;
				da=bas_sal*16/100;
				tax=bas_sal*16/100;
				pr=bas_sal*12/100;
		
			}
			
			
			else {
				
				hra=9*10/100;
				da=bas_sal*5/100;
				tax=bas_sal*5/100;
				pr=bas_sal*7/100;
				
				
			}
			
			tot_ear= bas_sal + hra + da;
			tot_ded = tax+pr;
			gross = tot_ear-tot_ded;
					
					System.out.println("===================================================");
					System.out.println("Salary Slip for the month of February 2022");
					System.out.println("===================================================");
					
					
					
					
			System.out.println("Your base salary is"+"  "+bas_sal);
			System.out.println("Your hra  is"+"  "+hra);
			System.out.println("Your da is"+"  "+da);
			System.out.println("Your tax is"+"  "+tax);
			System.out.println("Your pr is"+"  "+pr);
			
			System.out.println("===================================================");
			
			
			System.out.println("Your total earnings is"+"  "+tot_ear);
			System.out.println("Your deduction is"+"  "+tot_ded);
			
			System.out.println("===================================================");
			
			System.out.println("Upon calculation, your net pay should be" +"  "+ gross);

			i++;
		}
		
		
		
	}

}
