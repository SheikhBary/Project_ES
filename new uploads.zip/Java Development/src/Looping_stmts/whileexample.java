package Looping_stmts;
import java.util.Scanner;
public class whileexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner (System.in);
		
		//noc = number of chocolates
		//nop = number of people
		
		System.out.println("Enter the number of Chocolates");
		int noc=s.nextInt();
		System.out.println("Enter the number of people");
		int nop=s.nextInt();
		
		
		
		while(noc>nop) {
			
			System.out.println("Name");
			String name =s.next();
					
			System.out.println("Age");
			int age =s.nextInt();		
			
			System.out.println("Gender");
			String gender =s.next();
			
			System.out.println("Number of chocolates you would like to have?");
			int CN =s.nextInt();		
			
			
			
			if (age<=2) {
				
				
				System.out.println("Sorry you are too young");
			}
			
			
			 else if (age <=4) {
				
				 System.out.println("Alright but I will inform your mother");
				 noc=noc-CN;
			}
			
			
			 else {
				 System.out.println("Here you go!");
				 noc = noc-CN;
				 
			 }
			
			
			System.out.println(noc + "  Chocolates Left");
			
			addExclamationMark("Hope to see you again");
		}
		

		}
	
	public static void addExclamationMark(String s) {
		
		System.out.println(s + "!");

	}

}
