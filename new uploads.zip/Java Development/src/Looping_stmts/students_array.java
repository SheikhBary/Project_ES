package Looping_stmts;
import java.util.Scanner;
public class students_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner (System.in);
		int no_of_students;
		
		
		System.out.println("Please enter number of students");
		no_of_students=s.nextInt();
		int regNo[] =new int [no_of_students];
		String student_name[]= new String [no_of_students];
		String dept [] = new String [no_of_students];
		String result[] = new String [no_of_students];
		char choice = 0 ;
		
		System.out.println("Please enter the details for the students");
		
			do {
		
		for (int i=0; i<no_of_students;i++) {
			
			System.out.println("Registration No");
			regNo[i]=s.nextInt();
			
			System.out.println("Student Name");
			student_name[i]=s.next();
			
			System.out.println("Department Name");
			dept[i]=s.next();
			
			System.out.println("Result");
			result[i]=s.next();
		}
		
		
		//Printing 
		
		//REG NO 
		System.out.println("Registration No");
		for ( int i:regNo)
		
		{
			System.out.println("Registration No"+i);
			
		}
		
		//STUDENT NAME
		System.out.println("Student Name");
		for ( String i:student_name)
		
		{
			System.out.println("Student Name"+i);
			
		}
		
		//DEPARTMENT NAME
				System.out.println("Department Name");
				for ( String i:dept)
				
				{
					System.out.println("Department Name"+i);
					
				}
				
				
		//RESULT 
				System.out.println("Result");
				for ( String i:result)
				
				{
					System.out.println("Result"+i);
					
				}	System.out.println("Do you wish to continue");
				choice =s.next().charAt(0);
			}	while (choice =='Y');
		
		
	}

}
