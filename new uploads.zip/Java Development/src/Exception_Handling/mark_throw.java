package Exception_Handling;
import java.util.Scanner;
public class mark_throw {
	
static void checkMark(int mark){
	if (mark<50) {
		throw new ArithmeticException ("You have Failed!");
		
		}
		
		else 
		{
			System.out.println("Congrats you have passed!");
			
		}
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int mark;
Scanner s = new Scanner (System.in);
System.out.println("What is your mark");
mark=s.nextInt();

checkMark(mark);

	}

}
