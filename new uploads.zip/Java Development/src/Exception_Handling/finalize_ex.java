package Exception_Handling;

public class finalize_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		finalize_ex o = new finalize_ex();
		
		System.out.println("Hash Code is:"+o.hashCode());
		o=null;
		System.gc();
		System.out.println("End of the garbage collection");
	}
	
	protected void finalize ()
	{
		System.out.println("called finalize () method");
	}
}
