package Exception_Handling;

public class multiple_catch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	try {
		String name = null;
		int str_len =name.length();
		
		
		System.out.println("Length of the string" + str_len);
		
		
		int a[]= new int [6];
		a[7]=43;
	}catch(NullPointerException e) {
		
		System.out.println(e);
	}catch(Exception e) {
		
		System.out.println(e);
	}
	
	System.out.println("Rest of code");

	}

}
