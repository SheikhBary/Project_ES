package Exception_Handling;
import java.io.*;
public class throws_ex {

	
	void M() throws IOException {
		System.out.println("Device operation performed");
		
	}
	
	void M1() throws IOException {
		System.out.println("Device operation performed");
		
	}
	public static void main(String[] args) throws IOException 
	
	{
		// TODO Auto-generated method stub

		throws_ex o = new throws_ex();
		throws_ex o1 = new throws_ex();
		o.M();
		o1.M1();
		System.out.println("Normal Flow");
	}

}
