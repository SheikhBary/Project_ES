package Exception_Handling;

public class null_pointer_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		String name = null;
		int str_len =name.length();
		
		
		System.out.println("Length of the string" + str_len);
		
		}catch(NullPointerException e)
		{
			System.out.println(e);
		}
		System.out.println("Length of the string");
	}

}
