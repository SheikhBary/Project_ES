package File_Handling;
import java.io.*;
public class Buffered_inputStream {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
			
		FileInputStream fis = new FileInputStream("D:\\test.txt");
		BufferedInputStream bis = new BufferedInputStream(fis);
		
		int i;
		
		while ((i=bis.read())!=-1)
		{
			System.out.print
			((char)i);
			
		}
		bis.close();
		fis.close();
		
	}

}
