package File_Handling;

public class error_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Error Message");
		System.err.println("Error Message");

	}

}
