package File_Handling;
import java.io.*;
public class print_writer {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		PrintWriter pc = new PrintWriter (System.out);
		
		pc.write("Data Can be Printed using Print Writer Example");
		
		pc.flush();
		pc.close();
		
		PrintWriter pw1 =null;
		
		FileWriter w = new FileWriter ("D:\\writer12.txt");
		pw1= new PrintWriter(w);
		pw1.write("This content is using print writer");
		pw1.flush();
		pw1.close();
	}

}
