package File_Handling;
import java.io.*;
public class String_reader {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		String s = "Welcome to java io package demo";
		
		StringReader sr = new StringReader(s);
		
		int i=0;
		while((i=sr.read())!=-1) {
			
			System.out.print((char)i);
		}

	}

}
