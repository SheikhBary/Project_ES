package File_Handling;
import java.io.*;
public class Char_arr_ex {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		char[] arr = {'h','e','l','l','o'};
		
		CharArrayReader rd = new CharArrayReader(arr);
		
		int k =0;
		while ((k=rd.read())!=-1)
		{
			char ch=(char)k;
			System.out.println(ch+":"+k);
			
			
		}
		
	}

}
