package File_Handling;
import java.io.*;
public class sequence_input {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		
		FileInputStream fis1 = new FileInputStream("D:\\test.txt");
		FileInputStream fis2 = new FileInputStream("D:\\test12.txt");
		
		SequenceInputStream sip= new SequenceInputStream(fis1,fis2);
		
		int i;
		
		while ((i=sip.read())!=-1)
		{
			
			System.out.print((char)i);
		}
		
		sip.close();
		fis1.close();
		fis1.close();
	}

}
