package File_Handling;
import java.io.*;


class Employee 
{
	int emp_id, salary;
	String name;
	
	public Employee(int emp_id, int salary, String name)
	{
		this.emp_id=emp_id;
		this.salary=salary;
		this.name=name;
	}
}
public class Serialization_demo {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
try {
		Employee e1 = new Employee(10, 2500, "Sheikh");
		
		FileOutputStream fos = new FileOutputStream("D:\\123.txt");
		ObjectOutputStream os = new ObjectOutputStream(fos);
		
		os.writeObject(e1);
		os.close();
		fos.close();
}catch(Exception e)
{
	System.out.println(e);
}
		
		
		
		
	}

}
