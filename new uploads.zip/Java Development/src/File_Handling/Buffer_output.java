package File_Handling;
import java.io.*;

public class Buffer_output {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		FileOutputStream fos = new FileOutputStream("D:\\test.txt");
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		
		String s = "File output using buffered output stream1";
		
		byte b [] = s.getBytes();
		
		bos.write(b);
		bos.flush();
		bos.close();
		fos.close();
		
		System.out.println("Success");
	}

}
