package File_Handling;
import java.io.*;
public class byte_arr {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		FileOutputStream f1= new FileOutputStream("D:\\f1.txt");
		FileOutputStream f2 = new FileOutputStream("D:\\f2.txt");
		String msg = "Hello World";
		byte b[] = msg.getBytes();
		ByteArrayOutputStream bo = new ByteArrayOutputStream();
		
		bo.write(b);
		bo.writeTo(f1);
		bo.writeTo(f2);
		
		bo.flush();
		bo.close();
		
		System.out.println("Success");

	}

}
