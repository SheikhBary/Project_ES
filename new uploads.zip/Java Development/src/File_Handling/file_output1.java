package File_Handling;

import java.io.*;

public class file_output1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	try {
			
			FileOutputStream f = new FileOutputStream("D:\\test12.txt");
			String msg = " Java file handling can be done using io package";
			byte b[] = msg.getBytes();//Convert msg to byte that can be stored in write
			f.write(b); //ASCII CODE
			f.close();
			System.out.println("Sucessfully Transferred");
		}catch(Exception e) {
			System.out.println(e);
		}

	}

}
