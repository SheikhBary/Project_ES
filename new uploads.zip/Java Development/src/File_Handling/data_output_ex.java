package File_Handling;
import java.io.*;
public class data_output_ex {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		FileOutputStream f1 = new FileOutputStream("D:\\fout.txt");
		int msg = 100;
		float f = (float) 100.123;
		long l =656656;
		DataOutputStream d1 = new DataOutputStream(f1);
		
		d1.writeInt(msg);
		d1.writeFloat(f);
		d1.writeLong(l);
		
		d1.flush();
		d1.close();
		
		System.out.println("Success");
		
		
		
		FileInputStream fis = new FileInputStream("D:\\fout.txt");
		DataInputStream d2 = new DataInputStream(fis);
		
		System.out.println("Integer is " + msg);
		System.out.println("Float Number is " + f);
		System.out.println("Long is " + l);
	}

}
