package File_Handling;
import java.io.*;
public class char_writer_ex {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		CharArrayWriter ca = new CharArrayWriter ();
		
		ca.write("Character array writer Example");
		
		FileWriter w = new FileWriter ("D:\\writer1.txt");
		FileWriter w1 = new FileWriter ("D:\\writer2.txt");
		FileWriter w2 = new FileWriter ("D:\\writer3.txt");
		FileWriter w3 = new FileWriter ("D:\\writer4.txt");
		
		ca.writeTo(w);
		ca.writeTo(w1);
		ca.writeTo(w2);
		
		w.close();
		w1.close();
		w2.close();
		w3.close();
		
		System.out.println("Task Completed");
	}

}
