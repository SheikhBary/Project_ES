package File_Handling;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.*;
public class buffered_reader {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
FileWriter w = new FileWriter ("D:\\writer.txt");
BufferedWriter buf = new BufferedWriter(w);
		
		String msg = "Writer Class Example";
		
		buf.write(msg);
		buf.close();
		
		System.out.println("Task Completed");
		

		FileReader fr = new FileReader("D:\\writer.txt");
		BufferedReader br = new BufferedReader(fr);
		int data=br.read();
		while (data!=-1)
		{
			System.out.print((char)data);
			data=br.read();
		}
		

	}

}
