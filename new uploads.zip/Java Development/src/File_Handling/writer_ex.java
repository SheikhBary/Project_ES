package File_Handling;
import java.io.*;
public class writer_ex {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		
		FileWriter w = new FileWriter ("D:\\writer.txt");
		
		String msg = "Writer Class";
		
		w.write(msg);
		w.close();
		
		System.out.println("Task Completed");
		
FileReader r = new FileReader ("D:\\writer.txt");
		
		int data=r.read();
		while(data!=-1) {
		System.out.print((char)data);
		data=r.read();
		
		
		}
		
	
	}

}
