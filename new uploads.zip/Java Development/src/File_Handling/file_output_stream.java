package File_Handling;

import java.io.*;

public class file_output_stream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			FileOutputStream fout = new FileOutputStream("D:\\test12.txt");
			
			fout.write(67); //ASCII CODE
			fout.close();
			System.out.println("Sucessfully Written");
		}catch(Exception e) {
			System.out.println(e);
		}

	}

}
