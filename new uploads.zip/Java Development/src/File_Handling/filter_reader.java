package File_Handling;

import java.io.*;
class userfilterReader extends FilterReader{
	
	userfilterReader(Reader in)
	{
		super(in);
	}
	
	public int read() throws IOException
	{
		int i=super.read();
		if((char)i==' ')
			return ((int) '7');
		else 
			return i;
	}
}
public class filter_reader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			
			FileReader rd = new FileReader ("D:\\writer1.txt");
			userfilterReader ufr = new userfilterReader(rd);
			int i;
			while ((i=ufr.read())!=-1)
			{
				System.out.print((char)i);
				
			}
			ufr.close();
			rd.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}

}
