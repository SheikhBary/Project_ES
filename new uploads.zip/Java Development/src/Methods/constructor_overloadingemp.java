package Methods;



class emp1{
	
	String emp_name,com_name, city, department;
	int emp_id;
	
	emp1(){
		
		System.out.println("Default constructor");
		
	}
	
	
	emp1(String emp_name, String com_name){
		
		this.emp_name=emp_name;
		this.com_name=com_name;
	
	}
	
	
	emp1(int emp_id, String emp_name, String com_name, String city,String department){
		this.emp_id=emp_id;
		this.emp_name=emp_name;
		this.com_name=com_name;
		this.city=city;
		this.department=department;
		
	}
	
	
void display() {
		
		System.out.println("Employee Id" +emp_id);
		System.out.println("Name of Employee" +emp_name);
		System.out.println("Name of City:" +city);
		System.out.println("Registered Department:" +department);
	}
	
	
}
public class constructor_overloadingemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		emp1 s1 = new emp1();
		emp1 s2 = new emp1 ("Sheikh", " IDC");
		emp1 s3 = new emp1 (1011, " Sheikh", "IDC", "Singapore", "Finance");
		
		s1.display();
		System.out.println("=====================");
		s2.display();
		System.out.println("=====================");
		s3.display();

	}

}
