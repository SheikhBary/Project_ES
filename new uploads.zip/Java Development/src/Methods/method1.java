package Methods;
import java.util.Scanner;

 class demo{
	

		int add(int n1, int n2) {
			
			return n1+n2;
		}
		
		int subtract(int n1, int n2) {
			
			return n1-n2;
		}

		int multiply(int n1, int n2) {
		
		return n1*n2;
		}

		float divide(int n1, int n2) {
		
		return n1/n2;
		}

		float modulus(int n1, int n2) {
		
		return n1%n2;
		}
}
public class method1 {
	
		
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a,b;
		
		Scanner s =new Scanner(System.in);
		
		System.out.println("Enter a value");
		a =s.nextInt();
		
		System.out.println("Enter a value");
		b =s.nextInt();
		
		
		demo m =new demo();
		//Add
		System.out.println(m.add(a, b));
		
		//Subtract
		
		System.out.println(m.subtract(a, b));

		//Multiply
		
		System.out.println(m.multiply(a, b));
	
		
		
		//Divide
		
		System.out.println(m.divide(a, b));
		
		
		
		//Modulus
		System.out.println("Modulus is"+m.modulus(a, b));
	
		

	}

}
