package Methods;
import java.util.Scanner;
public class arith {

	
	int num1, num2;
	float n1, n2,result;
	
	Scanner s =new Scanner (System.in);
	
	int add() {
		
		System.out.println("Enter the value for number1");
		n1=s.nextFloat();
		System.out.println("Enter the value for number2");
		n2=s.nextFloat();
		return (int) (n1+n2);
		
	}
	
	
	int sub() {
		
		System.out.println("Enter the value for number1");
		n1=s.nextFloat();
		System.out.println("Enter the value for number2");
		n2=s.nextFloat();
		return (int) (n1-n2);
		
	}
	
	
	float mul() {
		
		System.out.println("Enter the value for number1");
		n1=s.nextFloat();
		System.out.println("Enter the value for number2");
		n2=s.nextFloat();
		return (int) (n1*n2);
		
		
	}
	
	
	float div () {
		System.out.println("Enter the value for number1");
		n1=s.nextFloat();
		System.out.println("Enter the value for number2");
		n2=s.nextFloat();
		return (int) (n1/n2);
	}
	
	float modulus () {
		System.out.println("Enter the value for number1");
		n1=s.nextFloat();
		System.out.println("Enter the value for number2");
		n2=s.nextFloat();
		return (int) (n1%n2);
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		arith a =new arith();
		arith b = new arith();
		arith c = new arith();
		System.out.println("Addition is :" + a.add());
		System.out.println("Subtraction is :" + b.sub());
		System.out.println("Multiplication is :" + b.mul());
		System.out.println("Division is :" + c.div());
		System.out.println("modulus is :" + c.modulus());
	}

}
