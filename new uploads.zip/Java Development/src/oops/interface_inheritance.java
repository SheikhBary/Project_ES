package oops;

interface printer 
{
	
	void print();
	
	default void msg()
	
	{
		
		System.out.println("from interface printer");
	}

	void printing();
}


interface scanner extends printer 

{
	void scan ();
	
	static int cube (int n)
	
	{
		
		return n*n*n;
	}

	void scanning();
	
}


 class hello implements printer,scanner 

{	

	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Printing");
	}


	
	public void scan() {
		// TODO Auto-generated method stub
		System.out.println("Scanning");
	}



	@Override
	public void scanning() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void printing() {
		// TODO Auto-generated method stub
		
	}
}
public class interface_inheritance {

	public static void main(String[] args) {    
		// TODO Auto-generated method stub
		
		
		hello h = new hello ();
		
		h.print();
		h.scan();
		h.msg();

	}

}
