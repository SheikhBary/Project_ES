package oops;
import java.util.Scanner;
public class challenge_course {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner (System.in);
		
		int tot;
		
		String [] courses = {"Law", "ComputerScience", "MBA", "Pharmaceutical", "Mechanical Engineering","Physiology"};
	
		
		System.out.println("Enter the number of courses");
		tot=s.nextInt();
		
		for (int i=0; i<tot; i++)   
		{  
		System.out.println(courses[i]);  
		}  

	}

}
