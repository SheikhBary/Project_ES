package oops;

import java.util.Scanner;

class armstrong{
	
	static int armstrong1, armstrong2, armstrong3, armstrongNumber;
	static Scanner s = new Scanner (System.in);
	
	static void display(){
	System.out.println("Please Enter the 3 digit number");
	armstrongNumber=s.nextInt();	
	System.out.println("Please Enter the first digit of your 3 digit number");
	armstrong1=s.nextInt();
	System.out.println("Please Enter the second digit of your 3 digit number");
	armstrong2=s.nextInt();
	System.out.println("Please Enter the third digit of your 3 digit number");
	armstrong3=s.nextInt();
	}
	
	static void calculate () {
	
		int power = 3;
		int first = (int) Math.pow(armstrong1, power);
		int second = (int) Math.pow(armstrong2, power);
		int third = (int) Math.pow(armstrong3, power);
		
		int total = first + second + third;
		
		
		if (total == armstrongNumber) {
			
			System.out.println(armstrongNumber+" is an armstrong Number");
		}
		
		else {
			System.out.println(armstrongNumber+" is not an armstrong Number");
			
		}
	}
	
}
public class armstrong_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		armstrong.display();
		armstrong.calculate();
	}

}
