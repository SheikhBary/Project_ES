package oops;
import java.util.Scanner;


class getnum{
	
	static int count;
	
	static void fib(int count) {
		
		int n1=0,n2=1,n3,i;
		System.out.println(n1+""+n2);
		for (i=2;i<count;i++) {
			
			n3=n1+n2;
			System.out.println("" +n3);
			n1=n2;
			n2=n3;
		}
	}
	
	
}


public class number_series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Scanner s = new Scanner (System.in);
		System.out.println("Enter the number");
		int n =s.nextInt();
		getnum.fib(n);
	}

}
