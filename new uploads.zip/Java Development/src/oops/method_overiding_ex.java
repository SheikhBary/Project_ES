package oops;


class parent{
	
	void show() {
		
		System.out.println("from parent class");
	}
	int calc(int a, int b) {
		
		return a+b;
	}
	
}

class child1 extends parent{
void show() {
		
		System.out.println("from child class");
	}

	int calc(int a, int b) {
	
	return a*b;
	}
	
}

class grandChild extends child1 {
void show() {
		
		System.out.println("from GrandChild class");
	}
	int calc( int a, int b)
	{
		return a-b;
	}
}
public class method_overiding_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parent p = new parent();
		child1 c = new child1();
		grandChild gc = new grandChild();
		
		p.show();
		System.out.println(p.calc(20, 30));
		c.show();
		System.out.println(c.calc(20, 30));
		gc.show();
		
		
		
		System.out.println(gc.calc(20, 30));
	}

}
