package oops;



abstract class banker {
	 abstract int roi();
	 
	 banker () {
		System.out.println("Demo Abstraction");
	}
	 
	
	 
	 void show () {
		 System.out.println("Concrete method from abstract method");
	 }
	 
}


class JAMES extends banker{

	int roi() 
	{
	return 14;
	}
	
	
}

class PETER extends banker{
	int roi() 
	{
	return 14;
	}
	
	
}
public class Abstraction_SL1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PETER p = new PETER();
		JAMES j = new JAMES();
		
		System.out.println("Peter Charges " + p.roi() + " percent for its services");
	
		System.out.println("James Charges " + j.roi() + " percent for its services");
	}

}
