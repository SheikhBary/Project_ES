package oops;

public class default_const {
	int reg_no;
	String name;
	float marks;
	boolean result;
	
	
	void display () {
		
		System.out.println(reg_no);
		System.out.println(name);
		System.out.println(marks);
		System.out.println(result);
		
	}
	public static void main(String[] args) {
		
		default_const d = new default_const();
		
		d.display();
		
		// TODO Auto-generated method stub

	}

}
