package oops;

class details{
	
	String schoolName, name, address;
	
	
	details(String schoolName, String name, String address){
		this.schoolName= schoolName;
		this.name= name;
		this.address= address;
	}
	
}


class student {
	
	int regNo;
	String dept;
	details details;
	student(int regNo, String dept, details details){
		
		this.regNo=regNo;
		this.dept=dept;
		this.details=details;
	}
	
	void display() {
		
		System.out.println(regNo+" " + dept + " " + details );
		System.out.println(details.schoolName+" " + details.name + " " + details.address );
	}
	
}

public class aggregrationstu_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		details d = new details ("Yishun JC", "Sheikh", " Yishun");
		details d1 = new details ("Hwa Chong JC", "Arul", " Jurong");
		details d2 = new details ("Temasek JC", "Nadine", " Bedok");
		
		
		student e =new student(1011,"Science", d);
		student e1 =new student(1011,"Science", d1);
		student e2 =new student(1011,"Science", d2);
		
		
		e.display();
		e1.display();
		e2.display();
	}

}
