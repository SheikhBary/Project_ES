package oops;
interface Bank1 {
	
	long Acc_no=4265656565L;
	int roi ();
	
}


class HDFCI implements Bank1

{
	public int roi()
	{
		return 15;
	}
	
}
public class interface_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HDFCI h= new HDFCI ();
		
		System.out.println("HDFC interest is :" + h.roi());
		
		Bank1.Acc_no=321321321L;
		System.out.println(Bank1.Acc_no);
	
	}

}
