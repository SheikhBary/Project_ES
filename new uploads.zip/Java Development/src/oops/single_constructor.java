package oops;
import java.util.Scanner;


	
	class Stu {
		
		int reg_no, mark1,mark2,mark3,tot,avg;
		String Dept,name;
		boolean result;
		char grade;
		
		Scanner s = new Scanner (System.in);
		
		void getData() {
			
			System.out.println("Enter the Reg_No");
			reg_no=s.nextInt();
			
			System.out.println("Enter Name");
			name=s.next();
			
			System.out.println("Enter First Mark");
			mark1=s.nextInt();
			
			System.out.println("Enter Second Mark");
			mark2=s.nextInt();
			
			System.out.println("Enter Third Mark");
			mark3=s.nextInt();
			
			System.out.println("Enter Department Name");
			Dept=s.next();
			
			
		}
		
		
		
		
		
		
	}
	
	
	class marklist extends Stu{
		
		int tot,avg;
		
		void m_list() {
		tot=mark1+mark2+mark3;
		avg=tot/3;
		
		
		if (avg>80) {
			
			grade='A';
		}
		
		else if (avg<80 && avg >70) {
			
			
			grade='B';
		}
		
	else if (avg<70 && avg >50) {
			
			
			grade='C';
		}
		
	else if (avg<50 && avg >30) {
		
		
		grade='D';
	}
		
	else {
		
		grade ='F';
	}
		
		
		
		}
	
	
	
	//Print 
	
	void report () {
		
		System.out.println("===================================================");
		System.out.println("Student Marklist");
		System.out.println("===================================================");
		
	

		
System.out.println("RegNo:" +reg_no);		
		

System.out.println("-----------------------------------------------------------------");

System.out.println("First Mark:" + mark1+"                          " + "Department:"+ Dept);
System.out.println("Second Mark:" + mark2);
System.out.println("Third Mark:" + mark3);
System.out.println("-----------------------------------------------------------------");
System.out.println("Total Mark:" + tot +"                          " + "Average Mark:"+ avg);		
System.out.println("Result:" + result +"                               " + "Grade:" +grade);			
	
	}
	}
	public class single_constructor {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		marklist m = new marklist ();
		
		
		m.getData();
		m.m_list();
		m.report();

	}
	}
	

