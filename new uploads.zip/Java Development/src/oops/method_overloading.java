package oops;


class demo {
	
	int add(int a, int b)
	
	{
		
		return a+b;
	}
	
	int add(int a, int b, int c)
	
	{
		
		return a*b*c;
		
	}
	
	double add(double n1, double n2) {
		
		return n1*n2;
	}
}




public class method_overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		demo d = new demo();
		
		System.out.println(d.add(34, 65));
		System.out.println(d.add(34, 65,32));
		System.out.println(d.add(34.5,43.5));
	}

}
