package oops;
import java.util.Scanner;

class getData1 {
	Scanner s = new Scanner (System.in);
	float net,age, salary;
	float cpf;
	String name;
	
	
	void EMP_D() {
	System.out.println("What is your name?");
	 String name = s.next();
	 
	 System.out.println("What is your Salary?");
	  salary = s.nextFloat();
	 
	 System.out.println("What is your Age?");
	  age = s.nextFloat();
	 
	}
	
	void clc ()
	{
		System.out.println(salary);
		 
		 
		 
	}
	
}

class calculate1 extends getData1 {
	void print() {
		
		System.out.println("Your cpf is " + cpf);
		 
	}
	

}

class report extends calculate1 {
	
	void report() {
		cpf = salary*17/100;
		
		System.out.println(cpf);
		 
	}
	
}

public class Inheritance_SL1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		report obj= new report();
		
		obj.EMP_D();
		obj.clc();
		obj.report();
	
		
		
	}

}
