package oops;

abstract class bank{
bank(){
		
		System.out.println("Abstraction Demo");
	}
	abstract int roi();
	
	

	void show()
	
	{
		System.out.println("Concrete method from abstract method");
		
	}
	

	
	
}
class HDFC extends bank{
	
	
	int roi() 
	{
	return 10;
	}
}


class SBI extends bank{
	int roi()
	{
	return 12;
	}
	
}


class ICICI extends bank{
	int roi() 
	{
	return 14;
	}
	
}

public class Abs_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		HDFC h = new HDFC ();
		ICICI i = new ICICI();
		SBI s = new SBI();
		
		
		
		System.out.println("HDFC interest is " + h.roi());
		System.out.println("ICICI interest is " + i.roi());
		System.out.println("SBI interest is " + s.roi());
	}

}
