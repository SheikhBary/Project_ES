package oops;

interface courses {
	
	public static final String name = "The course fee for";
	
	
	
}


class B_tech implements courses{
	
	
	int course_fee=5000;
	String id = "02";
	String course = "B_tech";
	public void course_fee() {
		
		
		System.out.println(name  + " "+ course + " with ID of " + id + " is " + course_fee);
	}
	
}

class M_tech implements courses{
	
	int course_fee=6000;
	String id = "03";
	String course = "M_tech";
public void course_fee() {
		
		
		System.out.println(name  +" "+ course + " with ID of " + id + " is " + course_fee);
	}
	
}

class Medical implements courses{
	
	int course_fee=7000;
	String id = "04";
	String course = "Medical";
public void course_fee() {
		
		
	System.out.println(name  + " "+course + " with ID of " + id + " is " + course_fee);
	}
	
}

public class interface_courses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B_tech b = new B_tech();
		M_tech m = new M_tech();
		Medical M = new Medical();
		
		b.course_fee();
		m.course_fee();
		M.course_fee();
	}

}
