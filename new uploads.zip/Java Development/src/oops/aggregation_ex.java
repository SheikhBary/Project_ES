package oops;


class Address{
	
	String city, state, country;
	Address (String city, String state, String country){
		
		this.city =city;
		this.state=state;
		this.country=country;
	}
	
}


class Emp{
	int id;
	String name;
	Address address;
	
	Emp(int id, String name, Address address)
	{
		
		this.id =id;
		this.name=name;
		this.address=address;
		
	}
	
	void display() {
		
		System.out.println(id +" "+ name);
		System.out.println(address.city+ "" + address.state+ "" + address.country);
	}
	
}
public class aggregation_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Address add1 =new Address ("gzb", "UP", "Singapore");
		Address add2 =new Address ("gzb", "UP", "Malaysia");
		Address add3 =new Address ("gzb", "UP", "India");
		
		
		Emp e1=new Emp (111, " Varun", add1);
		Emp e2=new Emp (111, " kol", add2);
		Emp e3=new Emp (111, " finn", add3);
		
		e1.display();
		e2.display();
		e3.display();
		
		
	}

}
