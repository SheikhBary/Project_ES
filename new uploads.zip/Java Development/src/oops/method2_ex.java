package oops;
import java.util.Scanner;

class Employee{
	
	String emp_name,address;
	int emp_id;
	Scanner s = new Scanner (System.in);
	String comp_name,city,dept;

	Employee(){
		
		
		System.out.println("Default Constructor");
	}
	
	
	Employee(String  comp_name,String city,String  dept){
		//String emp_name,int emp_id
		
		this.comp_name= comp_name;
		this.city= city;
		this.dept= dept;
		
	}
	
	void getData () {
		System.out.println("Enter Employee Name");
		 emp_name=s.next();
		System.out.println("Enter Employee ID");
		 emp_id=s.nextInt();
		System.out.println("Enter Employee Address");
		 address=s.next();
	}
	
	
	
	void display () {
		
		System.out.println("Company Name:" + comp_name);
		System.out.println("Name of Employee" +emp_name);
		System.out.println("Employee Id" + emp_id);
		System.out.println("Department:" + dept);
		System.out.println("Employee Address:" + address);
		System.out.println("City:" + city);
	
		
	}
	
}



public class method2_ex {

	public static void main(String[] args) {		
		// TODO Auto-generated method stub
		
	
		
		
		
		Employee e = new Employee();
		Employee a1 = new Employee ("IDC","Singapore", "Finance");
		a1.getData();
		a1.display();

		


		
	}

}
