package oops;

class Stu123 {
	
	int id, age;
	String name;
	
	public void setName(String name)
	{
		this.name=name;
		
	}
	
	public void setId(int id)
	{
		this.id=id;
		
	}
	
	public void setAge(int age)
	{
		this.age=age;
		
	}
	
	
	public String getName()
	{
		return this.name;
	}
	
	public int getId()
	{
		return this.id;
	}
	
	public int getAge()
	{
		return this.age;
	}

	public void id(int i) {
		// TODO Auto-generated method stub
		
	}
	
	
}




public class Encapsulation_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Using Bean or Pojo Class we can achieve encapsulation
		
		Stu123 s = new Stu123();
		
		s.setAge(23);
		s.setId(45);
		s.setName("Sheikh");
		
		
		System.out.println(s.getAge());
		System.out.println(s.getName());
		System.out.println(s.getId());
	}

}
