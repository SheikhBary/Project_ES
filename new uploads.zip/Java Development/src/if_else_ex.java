
public class if_else_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int with_amt, acc_bal;
		
		acc_bal=1000;
		with_amt=5000;
		
		if (acc_bal>with_amt)
			
		{
			
			System.out.println("Transaction Successful");
			acc_bal = acc_bal - with_amt;
			System.out.println("Your account balance is" + " " + acc_bal);
		}else {
			
			System.out.println("Sorry!... Insufficient Balance in your Account");
		}
		
	}

}
