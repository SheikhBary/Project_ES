package assessment_2;

public class challenge2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int t= 24;
		
		if ((t % 2) != 0) {
			
			System.out.println("Weird");//even
		} else if ((t % 2) == 0 && t>3 && t<9)
		{
			System.out.println("Not Weird");
		} else if ((t % 2) == 0 && t>10 && t<20)
		{
			System.out.println(" Weird");
		} else if ((t % 2) == 0 && t>10)
		{
			System.out.println("Not Weird");
		}

	}

}
