package assessment_2;


class Animal {
	
	void walk() {
		
		System.out.println("I am walking");
	}
	
}

class Bird extends Animal{
	
	void fly() {
		
		System.out.println("I am flying");
	}
	
	void Singing() {
		
		System.out.println("I am singing ");
	}
	
}
public class animals_program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bird b = new Bird();
		b.walk();
		b.fly();
		b.Singing();
		

	}

}
