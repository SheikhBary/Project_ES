package Multi_Thread;

public class TrialClass {

public TrialClass(Object o){
		
		System.out.println("It is an object");
	}
	
public TrialClass(String s){
		
		System.out.println("It is an string");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TrialClass trialclass = new TrialClass(null);
		new TrialClass("");

	}

}
