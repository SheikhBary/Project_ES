package Multi_Thread;
import java.util.Scanner;
class task1 extends Thread{
	public void run() {
		Scanner s = new Scanner (System.in);
		System.out.println("Enter n Value");
		int n =s.nextInt();
		for (int i=0;i<n;i++)
			
		{
			System.out.println("Thread 1:" +i);
		}
	}
}

class task2 extends Thread{
	public void run() {
		Scanner s = new Scanner (System.in);
		System.out.println("Enter n Value");
		int n =s.nextInt();
		for (int i=0;i<n;i++)
			
		{
			System.out.println("Thread 2:" +i);
		}
	}
}

class task3 extends Thread{
	public void run() {
		Scanner s = new Scanner (System.in);
		System.out.println("Enter n Value");
		int n =s.nextInt();
		for (int i=0;i<n;i++)
			
		{
			System.out.println("Thread 3:" +i);
		}
	}
}
public class multi_thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		task1 t1 = new task1();
		task2 t2 = new task2();
		task3 t3 = new task3();
		
		t1.start();
		t2.start();
		t3.start();

	}

}
