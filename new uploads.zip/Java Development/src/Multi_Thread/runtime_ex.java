package Multi_Thread;

public class runtime_ex {

	public static void main (String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		Runtime.getRuntime().exec("notepad");

	}

}
