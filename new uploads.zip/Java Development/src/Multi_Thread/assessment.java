package Multi_Thread;


public class assessment {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i =1;
		for (; i<10; i++) 
		{
			System.out.println(i);
		}
		
		System.out.println(i);
		
		for (;;;)
		{
			System.out.println("Inside loop");
		}
		
	}

}
