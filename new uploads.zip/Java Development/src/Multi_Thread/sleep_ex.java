package Multi_Thread;

public class sleep_ex extends Thread{

	
	public void run()
	
	{
		for (int i =0;i<5;i++)
		{
			try {
				Thread.sleep(500);
			}catch(InterruptedException e)
			{
				System.out.println(e);
			}
			System.out.println(i);
		}
		
		if(Thread.currentThread().isDaemon())
		{
			System.out.println("Daemon Thread work");
		}
		
		else {
			System.out.println("User Thread work");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread.currentThread().setPriority(10);
		sleep_ex T1 = new sleep_ex();
		sleep_ex T2 = new sleep_ex();
		sleep_ex T3 = new sleep_ex();
		
		T1.setPriority(8);
		T2.setPriority(7);
		T3.setPriority(6);
		T1.start();
		try {T1.join();}catch(Exception e) {System.out.println(e);}
		T2.start();
		try {T2.join();}catch(Exception e) {System.out.println(e);}
		//T3.start();
		
		T1.setName("First Thread");
		T2.setName("Second Thread");
		T3.setName("Third Thread");
		System.out.println(T1.getName());
		System.out.println(T2.getName());
		System.out.println(T3.getName());
		
		
		System.out.println("First Thread Priority" +T1.getPriority());
		System.out.println("Second Thread Priority" +T2.getPriority());
		System.out.println("Third Thread Priority" +T3.getPriority());
		
		
		T3.setDaemon(true);
		
		
		
		}
}
