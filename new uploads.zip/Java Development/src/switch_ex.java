
public class switch_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int bas_sal, hra;
		
		bas_sal=4500;
		switch(bas_sal) {
		
		
		case 1500:
			
			hra=bas_sal*20/100;
			System.out.println("Basic Salary :" +bas_sal+"HRA" +hra);
			break;
			
			
		case 2500:
			
			hra=bas_sal*25/100;
			System.out.println("Basic Salary :" +bas_sal+"HRA" +hra);
			break;
			
		case 4500:
			
			hra=bas_sal*28/100;
			System.out.println("Basic Salary :" +bas_sal+"HRA" +hra);
			break;
			
		default:
			
			hra=bas_sal*10/100;
			System.out.println("Basic Salary :" +bas_sal+"HRA" +hra);
			break;
			
			
		
		}

	}

}
