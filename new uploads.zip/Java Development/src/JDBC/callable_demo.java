package JDBC;
import java.sql.*;
public class callable_demo {
	
	

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
try {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","root");
		String query = "{call get_details(?)}";
		
		CallableStatement stmt =con.prepareCall(query);
		
		stmt.setInt(1, 102);
		
		
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			
			System.out.println(rs.getInt(1)+" "+ rs.getString(2)+" "+ rs.getInt(3));
		}
		con.close();
		
}catch ( Exception e)

{
	System.out.println(e);
}
		
		
		
		
		
	}

}
