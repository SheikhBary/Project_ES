package JDBC;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
public class mysql_insert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("What is your employee Id?");
		int newId =s.nextInt();
		
		System.out.println("What is your Full Name?");
		String newname =s.next();
		
		
		System.out.println("What is your latest Salary?");
		int newSalary =s.nextInt();
		
		
try {
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","root");
			
			Statement stmt =con.createStatement();
			
			//inserting data to table
			 String sqlInsert = "insert into emp_data values (1023, 'Sheikh', 2500)";
	         System.out.println("The SQL statement is: " + sqlInsert + "\n");  // Echo for debugging
	         int countInserted = stmt.executeUpdate(sqlInsert);
	         System.out.println(countInserted + " records inserted.\n");
	         
	        
	         
	       //reading data from the table
	         String strSelect = "select * from emp_data";
	         System.out.println("The SQL statement is: " + strSelect + "\n");  // Echo For debugging
	         ResultSet rs1 = stmt.executeQuery(strSelect);
	         
	         System.out.println("UPDATED TABLE");
	         while(rs1.next()) {   // Move the cursor to the next row
	        	
	            System.out.println(rs1.getInt("emp_id") + ", " + rs1.getString(2) + ", " + rs1.getInt(3));
	         }//for get () you can use both numbers or "example" to indicate the column name
			con.close();
			
			
			
		}catch (Exception e) {
			
			System.out.println(e);
		}

	}

}
