package JDBC;
import java.sql.*;
public class student_JDBC_contacts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try {
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","root");
			
			Statement stmt =con.createStatement();
			
			ResultSet rs1 =stmt.executeQuery("select * from contacts");
			
			while (rs1.next()) {
				
					System.out.println(rs1.getInt(1)+ rs1.getString(2) + rs1.getString(3) + rs1.getString(4)+ rs1.getString(5));
			}
			con.close();
			
		}catch (Exception e) {
			
			System.out.println(e);
		}

	}

}
