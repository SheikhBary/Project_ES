package JDBC;
import java.sql.*;
public class contacts_callable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","root");
			String query = "{call get_id(?)}";
			
			CallableStatement stmt =con.prepareCall(query);
			
			stmt.setInt(1, 102);
			
			
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next())
			{
				System.out.println(rs.getInt(1) + ", " +rs.getString(2) +", " + rs.getString(3) +", " + rs.getString(4) +", " + rs.getString(5));
			}
			
			// calling same procedure 2x
			 
CallableStatement stmt1 =con.prepareCall(query);
			
			stmt1.setInt(1, 3);
			
			
			ResultSet rs1 = stmt1.executeQuery();
			
			while (rs1.next())
			{
				System.out.println(rs1.getInt(1) + ", " +rs1.getString(2) +", " + rs1.getString(3) +", " + rs1.getString(4) +", " + rs1.getString(5));
			}
			
			con.close();
			
		}catch ( Exception e)
		
		{
			
			System.out.println(e);
		}

	}

}
