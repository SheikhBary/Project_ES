package default_package;
import java.util.Scanner;
public class challengeSwitch_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner (System.in);
		
		int cCode ;
		String dpt;
		
		System.out.println("Enter Course Code");
		cCode=s.nextInt();
		
		switch(cCode) {
		
		
		case 101:
			
			
			System.out.println("Department is "+"CSE");
			break;
			
			
		case 102:
			
			
			System.out.println("Department is "+"EEE");
			break;
			
		case 103:
			
			
			System.out.println("Department is "+"MECH");
			break;
			
		case 104:
			
		
			System.out.println("Department is "+"CIVIL");
			break;
			
		default:
			
			System.out.println("Invalid Course Code");
			break;
			
			
		
		}

	}



	}


