package default_package;

public class if_elseif_else_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int bas_sal,hra;
		bas_sal=3000;
		
		
		
		if (bas_sal>1000 && bas_sal<2000)
			
		{
			hra = bas_sal*20/100;
			System.out.println("Base Salary:" + bas_sal+ "   Hra:" + hra);
			
		}else if (bas_sal>2000 && bas_sal < 3000) {
			
			hra = bas_sal*25/100;
			System.out.println("Base Salary:" + bas_sal+ "   Hra:" + hra);
		}
		
		else if(bas_sal>3000 && bas_sal==3000){
			
			hra = bas_sal*28/100;
			System.out.println("Base Salary:" + bas_sal+ "   Hra:" + hra);
		}
		
		else {
			
			hra = bas_sal*10/100;
			System.out.println("Base Salary:" + bas_sal+ "   Hra:" + hra);
			
			
		}

	}

}
