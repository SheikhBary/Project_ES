package ExceptionalHandling;

public class IndexoutofBounds_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] decimal=new int[] {1, 2, 3};
		try {
		String[] strAr1=new String[] {"Ani", "Sam", "Joe"};
		
		System.out.println(strAr1[3]);
		
		}catch (Exception e) {
			System.out.println(e);
			
		}
		System.out.println(decimal[2]);

	}

}
