package ExceptionalHandling;

public class Exception_handling_Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
		
		int Salary = 25000;
		
		
		
		System.out.println("Salary is:" + Salary);
		int hra = Salary*15/0;
		System.out.println("HRA is :" + hra);
		} catch(ArithmeticException e)
		
		{
			System.out.println(e);
		}
		
		System.out.println("HRA is to be calculated");
	}

}
