module java_training {
}