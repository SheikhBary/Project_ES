package self_training;
import java.util.*;
public class Self_training1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create an output that print similar to assesment test 
		
		Scanner s = new Scanner (System.in);
		System.out.println("What is your preffered number");
		int a=s.nextInt();
		
		for (int i = 1;i<10;i++)
		{
			
			System.out.println(a + "x" + (i+1) + " = " + (a*(i+1)));
		}

	}

}
