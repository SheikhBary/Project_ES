package strings;

public class string_buf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer sb = new StringBuffer("Hello");
		
		sb.append("World");
		
		System.out.println("Using String Buffer"+sb);
		
		//String Class
		
		String  str1 = new String ("Hello");
		
		str1.concat("World");
		
		System.out.println("Using String class"+str1);
		
StringBuilder sb1 = new StringBuilder("New");
		
		sb1.append("Class");
		
		System.out.println("Using String Builder"+sb1);
		
		//String Methods
		
		System.out.println(sb1.insert(3, "Java"));
		System.out.println(sb1.replace(3,5, "lol"));
		System.out.println(sb1.delete(3,5));
	}

}
