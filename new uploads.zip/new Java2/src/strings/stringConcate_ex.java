package strings;

public class stringConcate_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a=110;
		int b =200;
		String c ="212";
		
		String s1 = "Welcome to Java Training Session";
		String s2 = "            Welcome to Java Session";
		
		System.out.println(a+b);
		System.out.println(a+c);
		System.out.println(c+b);
		
		System.out.println(c.concat("500"));
		System.out.println(c.charAt(0));
		
		System.out.println(s1.substring(10));
		System.out.println(s1.substring(5,10));
		
		System.out.println(s2.trim());
		System.out.println(s2.toLowerCase());
		System.out.println(s2.toUpperCase().trim());
		System.out.println(s2.length(  ));
	}

}
