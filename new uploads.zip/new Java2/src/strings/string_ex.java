package strings;

public class string_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//String is immutable 
		
		
		String str1 = "Hello";
		
		str1=str1.concat("World"); // Even after changing it, it does not change.
		
		
		System.out.println(str1);
		
		
		

	}

}
