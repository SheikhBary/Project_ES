package strings;

public class str_comparable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="Apple";
		String s2="Apple";
		String s3= new String ("Apple");
		
		String s4="Kiwi";
		
		System.out.println(s1.equals(s2)); //Comparing Values
		System.out.println(s1.equals(s3));
		System.out.println(s1.equals(s4));
		
		
		System.out.println(s1==s3); //Comparing Address
		
		System.out.println(s1.compareTo(s2)); //Comparing Values
	}

}
