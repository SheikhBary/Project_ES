package multi_thread;

public class runtime_ex {

	public static void main (String[] args)throws Exception {
		// TODO Auto-generated method stub
		
		Runtime.getRuntime().exec("notepad");

	}

}
