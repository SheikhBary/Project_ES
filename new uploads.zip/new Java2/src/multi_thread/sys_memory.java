package multi_thread;

public class sys_memory {

	public static void main(String[] args) throws Exception
	
	{
		// TODO Auto-generated method stub
		Runtime r =Runtime.getRuntime();
		System.out.println("Total Memory:" + r.totalMemory());
		System.out.println("Free Memory:" + r.freeMemory());
		
		for (int i=0;i<1000;i++)
		{
			new sys_memory();
		}
		
		System.out.println("After creating 1000 instance, free memory:" +r.freeMemory());
		System.gc();
		System.out.println("After gc(), free memory is :" + r.freeMemory());
	}

}
