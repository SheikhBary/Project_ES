const person = {
	
	fullName:function()
	{
		
		return this.firstName+""+this.lastName;
	}
}

const person1 ={
	
	firstName:"Hello",
	lastName:"World"
	
}

const person2 = {
	
	firstName:"Sachin",
	lastName:"Tendulkar"
}

console.log(person.fullName.apply(person1));
console.log(person.fullName.apply(person2));