 var x = 5;
 var y = 7;
//Arithmetic Operator
 console.log(x+y);
 console.log(x-y);
 console.log(x/y);
 console.log(y%x);
 
 
 //Logical Operator
 
  console.log(x!=y);
  
  
    console.log(x<y);