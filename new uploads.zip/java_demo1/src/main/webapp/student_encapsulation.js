class Stu {
	
	constructor ()
	{
		
		
		var name;
		var marks;
		
		
	}
		getName()
	{
		return this.name;
	}
	
	getMark()
	{
		return this.marks;
	}
	
	setName (name)
	{
		
		this.name=name;
	}
	
	setMarks (marks)
	{
		
		this.marks=marks;
	}

	
	
}


var e = new Stu ();

e.setName("Sheikh");
e.setMarks(64);

console.log("Student Name :" + e.getName());
console.log("Student Marks :" +e.getMark());