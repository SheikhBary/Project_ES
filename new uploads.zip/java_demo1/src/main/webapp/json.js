var product = [
	
	{name:"book" , price:250, nos:29},
	{name:"book1" , price:250, nos:29},
	{name:"book2" , price:250, nos:29},
	
]

console.log(product[0]);