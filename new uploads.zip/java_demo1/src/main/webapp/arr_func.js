var fun=()=> console.log('arrow function');
var fun1=(num1,num2)=> console.log('ans is :' + num1 * num2);

fun();
fun1(25,65);
fun();