function add (num1, num2){
	
	return(num1+num2);
}

function mul (num1, num2){
	
	return(num1*num2);
}

console.log(mul(21,33));
console.log(add(21,33));
