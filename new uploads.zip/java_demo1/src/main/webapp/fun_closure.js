let num = 0;


function sum ()

{
	let num =0;//function closure
	num+=2;
	console.log(num)
}

sum();
sum();
sum();

console.log("After changing num is :" + num);