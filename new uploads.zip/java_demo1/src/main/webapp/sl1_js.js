const array = [
	
	{name:"Sheikh", age:25, Salary:3000},
	{name:"Abdul", age:25, Salary:3000},
	{name:"Bary", age:25, Salary:3000},
]

console.log(array[0].name);

const array1 = ["Sheikh", 25, 3000];

console.log(array1);

function sum (num1, num2)

{
	
	return num1 * num2;
}

console.log(sum(24,54));



var s1 = "Apples"

var s2 = "Mapple"




var noa1= s1.length;
console.log(noa1);
var noa2 =s2.length;
console.log(noa2);


var char1 = s1.charAt(0);

console.log(char1);

var char2 = s2.charAt(0);

console.log(char2);



