class Emp {
	
	constructor ()
	
	{
		
		var name;
		var marks;
		
	}
	
	getName()
	{
		return this.name
	}
	
	getSalary()
	{
		
		return this.salary;
	}
	
	setName(name)
	{
		this.name=name;
	}
	
	setSalary(salary)
	{
		this.salary=salary;
	}
	
	
}

var e = new Emp();

e.setName("Sheikh");
e.setSalary(3500);

console.log("Name :" + e.getName());
console.log("Salary :" + e.getSalary());