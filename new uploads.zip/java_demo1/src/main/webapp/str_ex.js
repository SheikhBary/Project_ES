var str = "String 1";
var str2 = 'String2';

var str3 = new String( 'String3 it\'s');
var str4 = 'String4 \'ok\'';


console.log('String one:' +str);
console.log('String two:' +str2);
console.log('String one length:' +str.length)
console.log('String three:' +str3);
console.log('String four:' +str4);

console.log(str3.slice(0,6));
console.log(str.slice(-4));
console.log(str.replace("String","Replace By JS"));
console.log("concate:"+str.concat("3rd March"));

console.log("5th index character:" + str3.charAt(5));
console.log(str3.indexOf("String3"));

// Note to use trim() to remove unwanted space