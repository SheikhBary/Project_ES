class Emp 
{
	
	constructor (name,age,salary)
	{
		
		this.name=name;
		this.age=age;
		this.salary=salary;
	}
	
	
	display()
	{
		
		console.log("name :" + this.name);
		console.log("age  : " + this.age);
		console.log("Salary " +this.salary)
	}
	

}

class Report extends Emp 
{
	

}

const e = new Emp  ("Sachin",35,25000); e.display();
const e1 = new Emp ("John",25,35000); e1.display();
const e2 = new Emp ("Vishal",19,29000); e2.display();

const r = new Report  ("Sheikh",35,25000);r.display();
const r1 = new Report ("Kamal",25,35000); r1.display();
const r2 = new Report ("Abhinav",19,29000); r2.display();





