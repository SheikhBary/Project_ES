console.log("Hello World");

function change(){
document.getElementById("demo").innerHTML=" changed by Js";
x=document.getElementsByClassName("p2");  // Find the elements
for(var i = 0; i < x.length; i++){
x[i].innerText="Hello JavaScript!";    // Change the content
}

document.getElementsByClassName("e2")[0].innerHTML=" changed by Js";

}
