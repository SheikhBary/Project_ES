class c1 
{
	
	add(x,y)
	{
		console.log(x+y);
	}
}

class c2 extends c1
{
	
	add(x,y)
	
	{
		
		console.log(x*y);
	}
}

const obj = new c2();

obj.add(5,5);

