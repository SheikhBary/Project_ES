const names =['ssss','aaaa','Sheikh'];

console.log(names.sort());
console.log(names.sort().reverse);

let emp_id= new Array(1001,1002,1003,1004,1005,1006,1007)
console.log("ascending order"+emp_id.sort(function (a,b){return a-b}));
console.log("ascending order"+emp_id.sort(function (a,b){return b-a}));