var emp = {
	
	name: 'Sheikh',
	age:30,
	salary:3000
	
}


console.log(emp.name);


const product = ["fruit",30,3000]

console.log(product[0])


const product1 = [
	
	{name:'sheikh', age:30, salary:3000},
	{name:'sheikh1', age:30, salary:3000},
	{name:'sheikh2', age:30, salary:3000}
]
console.log(product1[0]);

let emp_id= new Array(1001,1002,1003,1004,1005,1006,1007)

console.log(emp_id);

for (let i=0;i<emp_id.length;i++)
{
	
	console.log(emp_id[i]);
}

emp_id.push(5055)
for (let i=0;i<emp_id.length;i++)
{
	
	console.log(emp_id[i]);
}

emp_id.pop()
for (let i=0;i<emp_id.length;i++)
{
	
	console.log(emp_id[i]);
}
