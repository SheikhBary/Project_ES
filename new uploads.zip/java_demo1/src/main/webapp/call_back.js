function display (result)

{
	
	console.log(result)
}

function calculate (x,y,callBack)
{
	let res = x +y;
	callBack(res);
}

calculate (10,34,display)
